import java.time.LocalDateTime;
import java.util.*;

class Message {
    private String sender;
    private String content;
    private LocalDateTime timestamp;
    private static Map<String, List<Message>> customerInboxes = new HashMap<>();
    private static Map<String, List<Message>> staffInboxes = new HashMap<>();

    public Message(String sender, String content) {
        this.sender = sender;
        this.content = content;
        this.timestamp = LocalDateTime.now();
    }

    public String getSender() {
        return sender;
    }

    public String getContent() {
        return content;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    public static void displayInbox(String username) {
        System.out.println("\n===== Inbox =====");

        Map<String, List<Message>> inbox;
        if (username.startsWith("customer")) {
            inbox = customerInboxes;
        } else {
            inbox = staffInboxes;
        }

        List<Message> messages = inbox.getOrDefault(username, new ArrayList<>());

        if (messages.isEmpty()) {
            System.out.println("Your inbox is empty.");
        } else {
            for (Message message : messages) {
                System.out.println("From: " + message.getSender() +
                        "\nSent at: " + message.getTimestamp() +
                        "\nMessage: " + message.getContent() + "\n");
            }
        }
    }

    public static void sendMessageToStaff(Scanner scanner, String receiverName, String customerUsername) {


        System.out.print("Enter your message to staff: ");
        String messageContent = scanner.nextLine();

        sendMessage(customerUsername, receiverName, messageContent);
        System.out.println("Message sent successfully!");
    }

    public static void sendMessageToCustomer(Scanner scanner,String receiverName, String staffUsername) {

        System.out.print("Enter your message to customer: ");
        String messageContent = scanner.nextLine();

        sendMessage(staffUsername, receiverName, messageContent);
        System.out.println("Message sent successfully!");
    }

    public static void sendMessage(String sender, String receiver, String content) {
        Message message = new Message(sender, content);

        if (receiver.startsWith("customer")) {
            customerInboxes.computeIfAbsent(receiver, k -> new ArrayList<>()).add(message);
        } else {
            staffInboxes.computeIfAbsent(receiver, k -> new ArrayList<>()).add(message);
        }
    }
}
